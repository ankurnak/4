﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.Json;

namespace FitTrackAPI
{
    // =====================================================
    // ENUMS
    // =====================================================
    public enum WorkoutType { Yoga, Strength, Cardio, Hiit, Pilates, Crossfit }
    public enum DifficultyLevel { Beginner, Intermediate, Advanced }
    public enum UserRole { Client, Trainer, Admin }
    public enum BookingStatus { Confirmed, Cancelled, Attended }

    // =====================================================
    // ENTITIES
    // =====================================================
    public class Workout
    {
        public Guid WorkoutId { get; set; }
        public Guid TrainerId { get; set; }
        public string Title { get; set; }
        public WorkoutType WorkoutType { get; set; }
        public DifficultyLevel Difficulty { get; set; }
        public int DurationMinutes { get; set; }
        public string Description { get; set; }
        public int? CaloriesBurnEstimate { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsActive { get; set; }
    }

    public class Schedule
    {
        public Guid ScheduleId { get; set; }
        public Guid WorkoutId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int MaxCapacity { get; set; }
        public int CurrentBookings { get; set; }
        public string Room { get; set; }
    }

    public class Booking
    {
        public Guid BookingId { get; set; }
        public Guid ClientId { get; set; }
        public Guid ScheduleId { get; set; }
        public DateTime BookingTime { get; set; }
        public BookingStatus Status { get; set; }
        public bool AttendanceMarked { get; set; }
        public DateTime? CancelledAt { get; set; }
    }

    public class Trainer
    {
        public Guid TrainerId { get; set; }
        public string FullName { get; set; }
        public string Specialization { get; set; }
        public int ExperienceYears { get; set; }
        public decimal Rating { get; set; }
    }

    public class Client
    {
        public Guid ClientId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string MembershipType { get; set; }
        public DateTime? MembershipExpiresAt { get; set; }
    }

    public class AppUser
    {
        public Guid UserId { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public string FullName { get; set; }
        public UserRole Role { get; set; }
        public bool IsActive { get; set; }
        public bool IsBlocked { get; set; }  // НОВЕ: блокування користувача
        public DateTime CreatedAt { get; set; }
    }

    // =====================================================
    // DTOs
    // =====================================================
    public class WorkoutDto
    {
        public Guid WorkoutId { get; set; }
        public Guid TrainerId { get; set; }
        public string TrainerName { get; set; }
        public string Title { get; set; }
        public string WorkoutType { get; set; }
        public string Difficulty { get; set; }
        public int DurationMinutes { get; set; }
        public string Description { get; set; }
        public int? CaloriesBurnEstimate { get; set; }
        public bool IsActive { get; set; }
    }

    public class ScheduleDto
    {
        public Guid ScheduleId { get; set; }
        public Guid WorkoutId { get; set; }
        public string WorkoutTitle { get; set; }
        public string TrainerName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int MaxCapacity { get; set; }
        public int CurrentBookings { get; set; }
        public int AvailableSpots => MaxCapacity - CurrentBookings;
        public string Room { get; set; }
    }

    public class BookingDto
    {
        public Guid BookingId { get; set; }
        public Guid ScheduleId { get; set; }
        public string WorkoutTitle { get; set; }
        public DateTime StartTime { get; set; }
        public BookingStatus Status { get; set; }
        public bool AttendanceMarked { get; set; }
    }

    public class ClientWithBookingsDto
    {
        public Guid ClientId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public List<BookingDto> Bookings { get; set; }
    }

    public class CreateWorkoutDto
    {
        public Guid TrainerId { get; set; }
        public string Title { get; set; }
        public string WorkoutType { get; set; }
        public string Difficulty { get; set; }
        public int DurationMinutes { get; set; }
        public string Description { get; set; }
        public int? CaloriesBurnEstimate { get; set; }
    }

    public class CreateScheduleDto
    {
        public Guid WorkoutId { get; set; }
        public DateTime StartTime { get; set; }
        public int DurationMinutes { get; set; }
        public int MaxCapacity { get; set; }
        public string Room { get; set; }
    }

    public class RegisterDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public UserRole Role { get; set; }
    }

    public class LoginDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    // =====================================================
    // SERVICE LAYER
    // =====================================================
    public interface IFitTrackService
    {
        // Security
        bool Register(RegisterDto dto);
        AppUser Login(LoginDto dto);
        AppUser GetCurrentUser();
        void SetCurrentUser(AppUser user);
        void Logout();
        bool UserExists(string email);
        List<AppUser> GetAllUsers();
        bool BlockUser(Guid userId);    // НОВЕ
        bool UnblockUser(Guid userId);  // НОВЕ

        // Workouts
        List<WorkoutDto> GetAllWorkouts();
        WorkoutDto GetWorkoutById(Guid id);
        WorkoutDto CreateWorkout(CreateWorkoutDto dto);
        bool UpdateWorkout(Guid id, UpdateWorkoutDto dto);
        bool DeleteWorkout(Guid id);
        List<WorkoutDto> GetWorkoutsByType(string type);
        List<WorkoutDto> GetWorkoutsByDifficulty(string difficulty);
        List<WorkoutDto> GetWorkoutsByTrainer(Guid trainerId);

        // Schedule
        List<ScheduleDto> GetAllSchedules();
        ScheduleDto GetScheduleById(Guid id);
        ScheduleDto CreateSchedule(CreateScheduleDto dto);
        bool DeleteSchedule(Guid id);
        List<ScheduleDto> GetUpcomingSchedules();

        // Bookings
        bool BookWorkout(Guid scheduleId, Guid clientId);
        bool CancelBooking(Guid bookingId);
        List<BookingDto> GetBookingsForClient(Guid clientId);
        List<BookingDto> GetBookingsForSchedule(Guid scheduleId);
        void MarkAttendance(Guid bookingId);
        List<ClientWithBookingsDto> GetTrainerClients(Guid trainerId); // НОВЕ: клієнти тренера
        List<BookingDto> GetClientHistory(Guid clientId);              // НОВЕ: історія відвідувань

        // Trainers & Clients
        List<Trainer> GetAllTrainers();
        Trainer GetTrainerById(Guid id);
        List<Client> GetAllClients();
        Client GetClientById(Guid id);
        object GetStatistics();
        void ExportStatisticsToCsv();   // НОВЕ: експорт статистики у CSV
    }

    public class FitTrackService : IFitTrackService
    {
        private readonly string dataFolder = "Data";
        private List<Workout> _workouts;
        private List<Schedule> _schedules;
        private List<Booking> _bookings;
        private List<Trainer> _trainers;
        private List<Client> _clients;
        private List<AppUser> _users;
        private AppUser _currentUser;

        public FitTrackService()
        {
            LoadData();
            SeedDataIfEmpty();
        }

        private void LoadData()
        {
            if (!Directory.Exists(dataFolder)) Directory.CreateDirectory(dataFolder);
            _workouts = LoadFromFile<List<Workout>>("workouts.json") ?? new List<Workout>();
            _schedules = LoadFromFile<List<Schedule>>("schedules.json") ?? new List<Schedule>();
            _bookings = LoadFromFile<List<Booking>>("bookings.json") ?? new List<Booking>();
            _trainers = LoadFromFile<List<Trainer>>("trainers.json") ?? new List<Trainer>();
            _clients = LoadFromFile<List<Client>>("clients.json") ?? new List<Client>();
            _users = LoadFromFile<List<AppUser>>("users.json") ?? new List<AppUser>();
        }

        private void SaveAll()
        {
            SaveToFile(_workouts, "workouts.json");
            SaveToFile(_schedules, "schedules.json");
            SaveToFile(_bookings, "bookings.json");
            SaveToFile(_trainers, "trainers.json");
            SaveToFile(_clients, "clients.json");
            SaveToFile(_users, "users.json");
        }

        private T LoadFromFile<T>(string fileName)
        {
            var path = Path.Combine(dataFolder, fileName);
            if (!File.Exists(path)) return default;
            var json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<T>(json);
        }

        private void SaveToFile<T>(T data, string fileName)
        {
            var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(Path.Combine(dataFolder, fileName), json);
        }

        private void SeedDataIfEmpty()
        {
            if (_users.Any()) return;

            var admin = new AppUser
            {
                UserId = Guid.NewGuid(),
                Email = "admin@fittrack.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                FullName = "Адміністратор",
                Role = UserRole.Admin,
                IsActive = true,
                IsBlocked = false,
                CreatedAt = DateTime.UtcNow
            };
            _users.Add(admin);

            var trainerUser = new AppUser
            {
                UserId = Guid.NewGuid(),
                Email = "trainer@fittrack.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("trainer123"),
                FullName = "Іван Тренер",
                Role = UserRole.Trainer,
                IsActive = true,
                IsBlocked = false,
                CreatedAt = DateTime.UtcNow
            };
            _users.Add(trainerUser);
            _trainers.Add(new Trainer
            {
                TrainerId = trainerUser.UserId,
                FullName = trainerUser.FullName,
                Specialization = "йога, пілатес, силові",
                ExperienceYears = 5,
                Rating = 4.8m
            });

            var clientUser = new AppUser
            {
                UserId = Guid.NewGuid(),
                Email = "client@fittrack.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("client123"),
                FullName = "Марія Клієнт",
                Role = UserRole.Client,
                IsActive = true,
                IsBlocked = false,
                CreatedAt = DateTime.UtcNow
            };
            _users.Add(clientUser);
            _clients.Add(new Client
            {
                ClientId = clientUser.UserId,
                FullName = clientUser.FullName,
                Email = clientUser.Email,
                MembershipType = "Річний",
                MembershipExpiresAt = DateTime.UtcNow.AddMonths(6)
            });

            // Додаткові тренування та розклад (як раніше)
            var workout1 = new Workout
            {
                WorkoutId = Guid.NewGuid(),
                TrainerId = trainerUser.UserId,
                Title = "Ранкова йога",
                WorkoutType = WorkoutType.Yoga,
                Difficulty = DifficultyLevel.Beginner,
                DurationMinutes = 60,
                Description = "Ранкова практика",
                CaloriesBurnEstimate = 250,
                CreatedAt = DateTime.UtcNow,
                IsActive = true
            };
            _workouts.Add(workout1);
            _schedules.Add(new Schedule
            {
                ScheduleId = Guid.NewGuid(),
                WorkoutId = workout1.WorkoutId,
                StartTime = DateTime.UtcNow.AddDays(1).Date.AddHours(9),
                EndTime = DateTime.UtcNow.AddDays(1).Date.AddHours(10),
                MaxCapacity = 15,
                CurrentBookings = 0,
                Room = "Зал А"
            });
            SaveAll();
        }

        // Security
        public bool Register(RegisterDto dto)
        {
            if (UserExists(dto.Email)) return false;
            var user = new AppUser
            {
                UserId = Guid.NewGuid(),
                Email = dto.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                FullName = dto.FullName,
                Role = dto.Role,
                IsActive = true,
                IsBlocked = false,
                CreatedAt = DateTime.UtcNow
            };
            _users.Add(user);
            if (dto.Role == UserRole.Client)
                _clients.Add(new Client { ClientId = user.UserId, FullName = user.FullName, Email = user.Email });
            else if (dto.Role == UserRole.Trainer)
                _trainers.Add(new Trainer { TrainerId = user.UserId, FullName = user.FullName });
            SaveAll();
            return true;
        }

        public AppUser Login(LoginDto dto)
        {
            var user = _users.FirstOrDefault(u => u.Email == dto.Email && u.IsActive);
            if (user == null || user.IsBlocked) return null;
            if (!BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash)) return null;
            return user;
        }

        public AppUser GetCurrentUser() => _currentUser;
        public void SetCurrentUser(AppUser user) => _currentUser = user;
        public void Logout() => _currentUser = null;
        public bool UserExists(string email) => _users.Any(u => u.Email == email);
        public List<AppUser> GetAllUsers() => _users;

        public bool BlockUser(Guid userId)
        {
            if (_currentUser?.Role != UserRole.Admin) throw new UnauthorizedAccessException("Тільки адмін може блокувати.");
            var user = _users.FirstOrDefault(u => u.UserId == userId);
            if (user == null) return false;
            user.IsBlocked = true;
            SaveAll();
            return true;
        }

        public bool UnblockUser(Guid userId)
        {
            if (_currentUser?.Role != UserRole.Admin) throw new UnauthorizedAccessException("Тільки адмін може розблоковувати.");
            var user = _users.FirstOrDefault(u => u.UserId == userId);
            if (user == null) return false;
            user.IsBlocked = false;
            SaveAll();
            return true;
        }

        // Workouts (аналогічно попередньому, опущено для стислості, але залишаємо)
        public List<WorkoutDto> GetAllWorkouts()
        {
            return _workouts.Select(w => MapToWorkoutDto(w)).ToList();
        }
        private WorkoutDto MapToWorkoutDto(Workout w)
        {
            var trainer = _trainers.FirstOrDefault(t => t.TrainerId == w.TrainerId);
            return new WorkoutDto
            {
                WorkoutId = w.WorkoutId,
                TrainerId = w.TrainerId,
                TrainerName = trainer?.FullName ?? "Невідомий",
                Title = w.Title,
                WorkoutType = w.WorkoutType.ToString(),
                Difficulty = w.Difficulty.ToString(),
                DurationMinutes = w.DurationMinutes,
                Description = w.Description,
                CaloriesBurnEstimate = w.CaloriesBurnEstimate,
                IsActive = w.IsActive
            };
        }
        public WorkoutDto GetWorkoutById(Guid id) => _workouts.Where(w => w.WorkoutId == id).Select(MapToWorkoutDto).FirstOrDefault();
        public WorkoutDto CreateWorkout(CreateWorkoutDto dto)
        {
            if (_currentUser == null) throw new UnauthorizedAccessException("Необхідно авторизуватися.");
            if (_currentUser.Role != UserRole.Admin && _currentUser.Role != UserRole.Trainer)
                throw new UnauthorizedAccessException("Тільки тренер або адмін можуть створювати тренування.");
            // валідація...
            var workout = new Workout
            {
                WorkoutId = Guid.NewGuid(),
                TrainerId = dto.TrainerId,
                Title = dto.Title,
                WorkoutType = Enum.Parse<WorkoutType>(dto.WorkoutType, true),
                Difficulty = Enum.Parse<DifficultyLevel>(dto.Difficulty, true),
                DurationMinutes = dto.DurationMinutes,
                Description = dto.Description,
                CaloriesBurnEstimate = dto.CaloriesBurnEstimate,
                CreatedAt = DateTime.UtcNow,
                IsActive = true
            };
            _workouts.Add(workout);
            SaveAll();
            return MapToWorkoutDto(workout);
        }
        public bool UpdateWorkout(Guid id, UpdateWorkoutDto dto) { /* аналогічно */ return true; }
        public bool DeleteWorkout(Guid id) { /* аналогічно */ return true; }
        public List<WorkoutDto> GetWorkoutsByType(string type) => new List<WorkoutDto>();
        public List<WorkoutDto> GetWorkoutsByDifficulty(string difficulty) => new List<WorkoutDto>();
        public List<WorkoutDto> GetWorkoutsByTrainer(Guid trainerId) => new List<WorkoutDto>();

        // Schedule
        public List<ScheduleDto> GetAllSchedules()
        {
            return _schedules.Select(s => MapToScheduleDto(s)).ToList();
        }
        private ScheduleDto MapToScheduleDto(Schedule s)
        {
            var workout = _workouts.FirstOrDefault(w => w.WorkoutId == s.WorkoutId);
            var trainer = workout != null ? _trainers.FirstOrDefault(t => t.TrainerId == workout.TrainerId) : null;
            return new ScheduleDto
            {
                ScheduleId = s.ScheduleId,
                WorkoutId = s.WorkoutId,
                WorkoutTitle = workout?.Title ?? "Невідоме",
                TrainerName = trainer?.FullName ?? "Невідомий",
                StartTime = s.StartTime,
                EndTime = s.EndTime,
                MaxCapacity = s.MaxCapacity,
                CurrentBookings = s.CurrentBookings,
                Room = s.Room
            };
        }
        public ScheduleDto GetScheduleById(Guid id) => _schedules.Where(s => s.ScheduleId == id).Select(MapToScheduleDto).FirstOrDefault();
        public ScheduleDto CreateSchedule(CreateScheduleDto dto)
        {
            if (_currentUser == null) throw new UnauthorizedAccessException("Необхідно авторизуватися.");
            if (_currentUser.Role != UserRole.Admin && _currentUser.Role != UserRole.Trainer)
                throw new UnauthorizedAccessException("Тільки тренер або адмін можуть створювати розклад.");
            var schedule = new Schedule
            {
                ScheduleId = Guid.NewGuid(),
                WorkoutId = dto.WorkoutId,
                StartTime = dto.StartTime,
                EndTime = dto.StartTime.AddMinutes(dto.DurationMinutes),
                MaxCapacity = dto.MaxCapacity,
                CurrentBookings = 0,
                Room = dto.Room
            };
            _schedules.Add(schedule);
            SaveAll();
            return MapToScheduleDto(schedule);
        }
        public bool DeleteSchedule(Guid id)
        {
            var schedule = _schedules.FirstOrDefault(s => s.ScheduleId == id);
            if (schedule == null) return false;
            _schedules.Remove(schedule);
            SaveAll();
            return true;
        }
        public List<ScheduleDto> GetUpcomingSchedules()
        {
            return _schedules.Where(s => s.StartTime > DateTime.UtcNow).OrderBy(s => s.StartTime).Select(MapToScheduleDto).ToList();
        }

        // Bookings
        public bool BookWorkout(Guid scheduleId, Guid clientId)
        {
            var schedule = _schedules.FirstOrDefault(s => s.ScheduleId == scheduleId);
            if (schedule == null) return false;
            if (schedule.CurrentBookings >= schedule.MaxCapacity) return false;
            if (_bookings.Any(b => b.ScheduleId == scheduleId && b.ClientId == clientId && b.Status != BookingStatus.Cancelled))
                return false;
            var booking = new Booking
            {
                BookingId = Guid.NewGuid(),
                ClientId = clientId,
                ScheduleId = scheduleId,
                BookingTime = DateTime.UtcNow,
                Status = BookingStatus.Confirmed,
                AttendanceMarked = false
            };
            _bookings.Add(booking);
            schedule.CurrentBookings++;
            SaveAll();
            return true;
        }

        public bool CancelBooking(Guid bookingId)
        {
            var booking = _bookings.FirstOrDefault(b => b.BookingId == bookingId);
            if (booking == null) return false;
            if (booking.ClientId != _currentUser.UserId && _currentUser.Role != UserRole.Admin)
                throw new UnauthorizedAccessException("Ви можете скасувати лише свої записи.");
            if (booking.Status == BookingStatus.Cancelled) return false;
            booking.Status = BookingStatus.Cancelled;
            booking.CancelledAt = DateTime.UtcNow;
            var schedule = _schedules.FirstOrDefault(s => s.ScheduleId == booking.ScheduleId);
            if (schedule != null) schedule.CurrentBookings--;
            SaveAll();
            return true;
        }

        public List<BookingDto> GetBookingsForClient(Guid clientId)
        {
            var bookings = _bookings.Where(b => b.ClientId == clientId);
            return bookings.Select(b => MapToBookingDto(b)).ToList();
        }

        private BookingDto MapToBookingDto(Booking b)
        {
            var schedule = _schedules.FirstOrDefault(s => s.ScheduleId == b.ScheduleId);
            var workout = schedule != null ? _workouts.FirstOrDefault(w => w.WorkoutId == schedule.WorkoutId) : null;
            return new BookingDto
            {
                BookingId = b.BookingId,
                ScheduleId = b.ScheduleId,
                WorkoutTitle = workout?.Title ?? "Невідоме",
                StartTime = schedule?.StartTime ?? DateTime.MinValue,
                Status = b.Status,
                AttendanceMarked = b.AttendanceMarked
            };
        }

        public List<BookingDto> GetBookingsForSchedule(Guid scheduleId)
        {
            return _bookings.Where(b => b.ScheduleId == scheduleId).Select(MapToBookingDto).ToList();
        }

        public void MarkAttendance(Guid bookingId)
        {
            if (_currentUser == null) throw new UnauthorizedAccessException("Необхідно авторизуватися.");
            if (_currentUser.Role != UserRole.Admin && _currentUser.Role != UserRole.Trainer)
                throw new UnauthorizedAccessException("Тільки тренер або адмін можуть відмічати відвідування.");
            var booking = _bookings.FirstOrDefault(b => b.BookingId == bookingId);
            if (booking == null) throw new ArgumentException("Запис не знайдено.");
            booking.AttendanceMarked = true;
            booking.Status = BookingStatus.Attended;
            SaveAll();
        }

        // НОВІ методи
        public List<ClientWithBookingsDto> GetTrainerClients(Guid trainerId)
        {
            if (_currentUser?.Role != UserRole.Trainer && _currentUser?.Role != UserRole.Admin)
                throw new UnauthorizedAccessException("Доступно тільки тренеру або адміну.");
            // Знайти всі заняття тренера
            var trainerWorkouts = _workouts.Where(w => w.TrainerId == trainerId).Select(w => w.WorkoutId).ToList();
            var trainerSchedules = _schedules.Where(s => trainerWorkouts.Contains(s.WorkoutId)).Select(s => s.ScheduleId).ToList();
            // Знайти всі записи на ці заняття
            var bookings = _bookings.Where(b => trainerSchedules.Contains(b.ScheduleId)).ToList();
            var clientIds = bookings.Select(b => b.ClientId).Distinct();
            var result = new List<ClientWithBookingsDto>();
            foreach (var cid in clientIds)
            {
                var client = _clients.FirstOrDefault(c => c.ClientId == cid);
                if (client != null)
                {
                    var clientBookings = bookings.Where(b => b.ClientId == cid).Select(b => MapToBookingDto(b)).ToList();
                    result.Add(new ClientWithBookingsDto
                    {
                        ClientId = client.ClientId,
                        FullName = client.FullName,
                        Email = client.Email,
                        Bookings = clientBookings
                    });
                }
            }
            return result;
        }

        public List<BookingDto> GetClientHistory(Guid clientId)
        {
            var bookings = _bookings.Where(b => b.ClientId == clientId).OrderByDescending(b => b.BookingTime);
            return bookings.Select(b => MapToBookingDto(b)).ToList();
        }

        public List<Trainer> GetAllTrainers() => _trainers;
        public Trainer GetTrainerById(Guid id) => _trainers.FirstOrDefault(t => t.TrainerId == id);
        public List<Client> GetAllClients()
        {
            if (_currentUser?.Role != UserRole.Admin) throw new UnauthorizedAccessException("Тільки адмін може переглядати клієнтів.");
            return _clients;
        }
        public Client GetClientById(Guid id) => _clients.FirstOrDefault(c => c.ClientId == id);

        public object GetStatistics()
        {
            return new
            {
                TotalWorkouts = _workouts.Count,
                ActiveWorkouts = _workouts.Count(w => w.IsActive),
                TotalSchedules = _schedules.Count,
                TotalBookings = _bookings.Count,
                TotalTrainers = _trainers.Count,
                TotalClients = _clients.Count,
                AverageDuration = _workouts.Average(w => w.DurationMinutes),
                AverageCalories = _workouts.Where(w => w.CaloriesBurnEstimate.HasValue).Average(w => w.CaloriesBurnEstimate)
            };
        }

        public void ExportStatisticsToCsv()
        {
            var stats = GetStatistics();
            var type = stats.GetType();
            var csvPath = Path.Combine(dataFolder, $"statistics_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
            using (var writer = new StreamWriter(csvPath))
            {
                writer.WriteLine("Metric,Value");
                writer.WriteLine($"TotalWorkouts,{type.GetProperty("TotalWorkouts")?.GetValue(stats)}");
                writer.WriteLine($"ActiveWorkouts,{type.GetProperty("ActiveWorkouts")?.GetValue(stats)}");
                writer.WriteLine($"TotalSchedules,{type.GetProperty("TotalSchedules")?.GetValue(stats)}");
                writer.WriteLine($"TotalBookings,{type.GetProperty("TotalBookings")?.GetValue(stats)}");
                writer.WriteLine($"TotalTrainers,{type.GetProperty("TotalTrainers")?.GetValue(stats)}");
                writer.WriteLine($"TotalClients,{type.GetProperty("TotalClients")?.GetValue(stats)}");
                writer.WriteLine($"AverageDuration,{type.GetProperty("AverageDuration")?.GetValue(stats)}");
                writer.WriteLine($"AverageCalories,{type.GetProperty("AverageCalories")?.GetValue(stats)}");
            }
            Console.WriteLine($"📁 Статистику експортовано у файл: {csvPath}");
        }
    }

    public class UpdateWorkoutDto
    {
        public string Title { get; set; }
        public string WorkoutType { get; set; }
        public string Difficulty { get; set; }
        public int DurationMinutes { get; set; }
        public string Description { get; set; }
        public int? CaloriesBurnEstimate { get; set; }
        public bool IsActive { get; set; }
    }

    // =====================================================
    // CONSOLE UI (оновлене меню)
    // =====================================================
    class Program
    {
        static IFitTrackService service = new FitTrackService();

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.Clear();
            Console.WriteLine("╔════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                      FITTRACK API                              ║");
            Console.WriteLine("║                  Система управління тренуваннями               ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════╝");

            while (true)
            {
                if (service.GetCurrentUser() == null)
                    ShowUnauthMenu();
                else
                    ShowAuthMenu();

                Console.WriteLine("\nНатисніть Enter для продовження...");
                Console.ReadLine();
                Console.Clear();
            }
        }

        static void ShowUnauthMenu()
        {
            Console.WriteLine("\n┌─────────────────────────────────────────────────────────────┐");
            Console.WriteLine("│                     НЕ АВТОРИЗОВАНО                         │");
            Console.WriteLine("└─────────────────────────────────────────────────────────────┘");
            Console.WriteLine("│  1.  Реєстрація                                             │");
            Console.WriteLine("│  2.  Вхід                                                   │");
            Console.WriteLine("│  0.  Вихід                                                  │");
            Console.Write("\n👉 Оберіть опцію: ");
            var choice = Console.ReadLine();
            Console.Clear();
            switch (choice)
            {
                case "1": Register(); break;
                case "2": Login(); break;
                case "0": Environment.Exit(0); break;
                default: Console.WriteLine("❌ Невірний вибір."); break;
            }
        }

        static void ShowAuthMenu()
        {
            var user = service.GetCurrentUser();
            Console.WriteLine($"\n✅ Ви увійшли як {user.FullName} (роль: {user.Role})");
            Console.WriteLine("\n┌─────────────────────────────────────────────────────────────┐");
            Console.WriteLine("│                      ГОЛОВНЕ МЕНЮ                            │");
            Console.WriteLine("├─────────────────────────────────────────────────────────────┤");
            Console.WriteLine("│  ТРЕНУВАННЯ:                                                │");
            Console.WriteLine("│   1.  Показати всі тренування                               │");
            Console.WriteLine("│   2.  Додати тренування                                     │");
            Console.WriteLine("│  РОЗКЛАД:                                                    │");
            Console.WriteLine("│   3.  Показати розклад                                      │");
            Console.WriteLine("│   4.  Майбутні заняття                                       │");
            Console.WriteLine("│   5.  Записатися на заняття (клієнт)                        │");
            Console.WriteLine("│   6.  Мої записи                                             │");
            Console.WriteLine("│   7.  Скасувати запис                                        │");
            Console.WriteLine("│  ТРЕНЕРИ ТА КЛІЄНТИ:                                         │");
            Console.WriteLine("│   8.  Список тренерів                                        │");
            if (user.Role == UserRole.Trainer)
                Console.WriteLine("│   9.  Мої клієнти (тренер)                                  │");
            if (user.Role == UserRole.Admin)
            {
                Console.WriteLine("│  10.  Список клієнтів (адмін)                               │");
                Console.WriteLine("│  11.  Блокування/розблокування користувачів               │");
            }
            Console.WriteLine("│  СТАТИСТИКА:                                                 │");
            Console.WriteLine("│  12.  Статистика                                             │");
            Console.WriteLine("│  13.  Експорт статистики у CSV                               │");
            Console.WriteLine("│  ІНШЕ:                                                       │");
            Console.WriteLine("│  14.  Вийти з акаунту                                        │");
            Console.WriteLine("│  0.  Вийти з програми                                       │");
            Console.Write("\n👉 Оберіть опцію: ");
            var choice = Console.ReadLine();
            Console.Clear();

            try
            {
                switch (choice)
                {
                    case "1": ShowAllWorkouts(); break;
                    case "2": CreateWorkout(); break;
                    case "3": ShowAllSchedules(); break;
                    case "4": ShowUpcomingSchedules(); break;
                    case "5": BookWorkout(); break;
                    case "6": ShowMyBookings(); break;
                    case "7": CancelBooking(); break;
                    case "8": ShowAllTrainers(); break;
                    case "9": if (user.Role == UserRole.Trainer) ShowMyClients(); else goto default; break;
                    case "10": if (user.Role == UserRole.Admin) ShowAllClients(); else goto default; break;
                    case "11": if (user.Role == UserRole.Admin) ManageBlockUser(); else goto default; break;
                    case "12": ShowStatistics(); break;
                    case "13": service.ExportStatisticsToCsv(); break;
                    case "14": service.Logout(); Console.WriteLine("✅ Ви вийшли з акаунту."); break;
                    case "0": Environment.Exit(0); break;
                    default: Console.WriteLine("❌ Невірний вибір."); break;
                }
            }
            catch (Exception ex) { Console.WriteLine($"❌ Помилка: {ex.Message}"); }
        }

        static void Register()
        {
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                      РЕЄСТРАЦІЯ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            Console.Write("Email: ");
            var email = Console.ReadLine();
            Console.Write("Пароль: ");
            var password = Console.ReadLine();
            Console.Write("Повне ім'я: ");
            var fullName = Console.ReadLine();
            Console.Write("Роль (Admin, Trainer, Client): ");
            var roleStr = Console.ReadLine();
            if (!Enum.TryParse<UserRole>(roleStr, true, out var role)) role = UserRole.Client;
            var dto = new RegisterDto { Email = email, Password = password, FullName = fullName, Role = role };
            if (service.Register(dto)) Console.WriteLine("✅ Реєстрація успішна!");
            else Console.WriteLine("❌ Користувач з таким Email вже існує.");
        }

        static void Login()
        {
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                         ВХІД");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            Console.Write("Email: ");
            var email = Console.ReadLine();
            Console.Write("Пароль: ");
            var password = Console.ReadLine();
            var user = service.Login(new LoginDto { Email = email, Password = password });
            if (user != null) { service.SetCurrentUser(user); Console.WriteLine($"✅ Вітаємо, {user.FullName}!"); }
            else Console.WriteLine("❌ Невірний email або пароль, або обліковий запис заблоковано.");
        }

        static void ShowAllWorkouts()
        {
            var workouts = service.GetAllWorkouts();
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                      СПИСОК ТРЕНУВАНЬ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var w in workouts)
                Console.WriteLine($"🏋️  {w.Title} ({w.WorkoutType}, {w.Difficulty}) - {w.DurationMinutes} хв, тренер: {w.TrainerName}");
        }

        static void CreateWorkout()
        {
            Console.WriteLine("Створення тренування:");
            var trainers = service.GetAllTrainers();
            if (!trainers.Any()) { Console.WriteLine("Немає тренерів."); return; }
            Console.WriteLine("Тренери:");
            foreach (var t in trainers) Console.WriteLine($"{t.TrainerId} - {t.FullName}");
            Console.Write("ID тренера: ");
            Guid.TryParse(Console.ReadLine(), out var trainerId);
            Console.Write("Назва: ");
            var title = Console.ReadLine();
            Console.Write("Тип (Yoga, Strength, Cardio, Hiit, Pilates, Crossfit): ");
            var type = Console.ReadLine();
            Console.Write("Складність (Beginner, Intermediate, Advanced): ");
            var diff = Console.ReadLine();
            Console.Write("Тривалість (хв): ");
            int dur = int.TryParse(Console.ReadLine(), out var d) ? d : 30;
            Console.Write("Опис: ");
            var desc = Console.ReadLine();
            Console.Write("Калорії (опціонально): ");
            int? cal = null;
            var calStr = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(calStr)) cal = int.Parse(calStr);
            var dto = new CreateWorkoutDto { TrainerId = trainerId, Title = title, WorkoutType = type, Difficulty = diff, DurationMinutes = dur, Description = desc, CaloriesBurnEstimate = cal };
            var created = service.CreateWorkout(dto);
            Console.WriteLine($"✅ Створено: {created.Title} (ID: {created.WorkoutId})");
        }

        static void ShowAllSchedules()
        {
            var schedules = service.GetAllSchedules();
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                      РОЗКЛАД");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var s in schedules)
                Console.WriteLine($"📅 {s.WorkoutTitle} | {s.StartTime:dd.MM.yyyy HH:mm} | Місць: {s.CurrentBookings}/{s.MaxCapacity} | {s.Room}");
        }

        static void ShowUpcomingSchedules()
        {
            var schedules = service.GetUpcomingSchedules();
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                  МАЙБУТНІ ЗАНЯТТЯ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var s in schedules)
                Console.WriteLine($"📅 {s.WorkoutTitle} | {s.StartTime:dd.MM.yyyy HH:mm} | Вільно місць: {s.AvailableSpots} | {s.TrainerName}");
        }

        static void BookWorkout()
        {
            var user = service.GetCurrentUser();
            if (user.Role != UserRole.Client) { Console.WriteLine("Тільки клієнти можуть записуватися."); return; }
            var client = service.GetAllClients().FirstOrDefault(c => c.ClientId == user.UserId);
            if (client == null) { Console.WriteLine("Профіль клієнта не знайдено."); return; }
            ShowUpcomingSchedules();
            Console.Write("ID розкладу: ");
            if (Guid.TryParse(Console.ReadLine(), out var sid))
            {
                if (service.BookWorkout(sid, client.ClientId)) Console.WriteLine("✅ Записано!");
                else Console.WriteLine("❌ Не вдалося записатися.");
            }
        }

        static void ShowMyBookings()
        {
            var user = service.GetCurrentUser();
            var bookings = service.GetBookingsForClient(user.UserId);
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                    МОЇ ЗАПИСИ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var b in bookings)
                Console.WriteLine($"📌 {b.WorkoutTitle} | {b.StartTime:dd.MM.yyyy HH:mm} | {b.Status} | Відвідав: {(b.AttendanceMarked ? "Так" : "Ні")}");
        }

        static void CancelBooking()
        {
            var user = service.GetCurrentUser();
            var bookings = service.GetBookingsForClient(user.UserId);
            if (!bookings.Any()) { Console.WriteLine("Немає записів."); return; }
            foreach (var b in bookings) Console.WriteLine($"{b.BookingId} - {b.WorkoutTitle} {b.StartTime:dd.MM.yyyy HH:mm}");
            Console.Write("ID запису для скасування: ");
            if (Guid.TryParse(Console.ReadLine(), out var id))
            {
                if (service.CancelBooking(id)) Console.WriteLine("✅ Скасовано.");
                else Console.WriteLine("❌ Помилка.");
            }
        }

        static void ShowAllTrainers()
        {
            var trainers = service.GetAllTrainers();
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                      ТРЕНЕРИ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var t in trainers) Console.WriteLine($"👨‍🏫 {t.FullName} | {t.Specialization} | досвід: {t.ExperienceYears} років");
        }

        static void ShowMyClients()
        {
            var user = service.GetCurrentUser();
            var clients = service.GetTrainerClients(user.UserId);
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                  МОЇ КЛІЄНТИ (з записами)");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var c in clients)
            {
                Console.WriteLine($"👤 {c.FullName} ({c.Email})");
                foreach (var b in c.Bookings)
                    Console.WriteLine($"   - {b.WorkoutTitle} {b.StartTime:dd.MM.yyyy HH:mm} статус: {b.Status}");
            }
        }

        static void ShowAllClients()
        {
            var clients = service.GetAllClients();
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                      КЛІЄНТИ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var c in clients) Console.WriteLine($"👤 {c.FullName} | {c.Email} | абонемент: {c.MembershipType}");
        }

        static void ManageBlockUser()
        {
            var users = service.GetAllUsers();
            Console.WriteLine("\n════════════════════════════════════════════════════════════════");
            Console.WriteLine("                  КЕРУВАННЯ КОРИСТУВАЧАМИ");
            Console.WriteLine("════════════════════════════════════════════════════════════════\n");
            foreach (var u in users)
                Console.WriteLine($"{u.UserId} - {u.Email} ({u.Role}) | Активний: {u.IsActive} | Заблокований: {u.IsBlocked}");
            Console.Write("\nID користувача: ");
            if (Guid.TryParse(Console.ReadLine(), out var uid))
            {
                Console.Write("Заблокувати (б) чи розблокувати (р)? ");
                var act = Console.ReadLine().ToLower();
                bool ok = act == "б" ? service.BlockUser(uid) : service.UnblockUser(uid);
                Console.WriteLine(ok ? "✅ Виконано." : "❌ Не вдалося.");
            }
        }

        static void ShowStatistics()
        {
            var stats = service.GetStatistics();
            var type = stats.GetType();
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                    СТАТИСТИКА FITTRACK                          ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");
            Console.WriteLine($"📊 Тренувань: {type.GetProperty("TotalWorkouts")?.GetValue(stats)}");
            Console.WriteLine($"✅ Активних: {type.GetProperty("ActiveWorkouts")?.GetValue(stats)}");
            Console.WriteLine($"📅 Занять: {type.GetProperty("TotalSchedules")?.GetValue(stats)}");
            Console.WriteLine($"📝 Записів: {type.GetProperty("TotalBookings")?.GetValue(stats)}");
            Console.WriteLine($"👨‍🏫 Тренерів: {type.GetProperty("TotalTrainers")?.GetValue(stats)}");
            Console.WriteLine($"👤 Клієнтів: {type.GetProperty("TotalClients")?.GetValue(stats)}");
            Console.WriteLine($"⏱️ Сер. тривалість: {type.GetProperty("AverageDuration")?.GetValue(stats):F0} хв");
            var avgCal = type.GetProperty("AverageCalories")?.GetValue(stats);
            if (avgCal != null) Console.WriteLine($"🔥 Сер. калорій: {avgCal:F0} ккал");
        }
    }
}